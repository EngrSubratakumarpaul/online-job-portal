﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication1
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //checking login data from database

            // Save Data
            string connetionString;
            SqlConnection conn;
            SqlCommand command;
            SqlDataReader dataReader;
            String sql, Output = " ";

            //Connection String
            connetionString = @"Data Source=SHUVO;Initial Catalog=demo; Integrated Security = true";
            conn = new SqlConnection(connetionString);           

           // Insert code
           sql = "select name, email from job_seeker_information where email = '" + UserName.Text + "' and password = '" + Password.Text + "'";
            try
            {
                conn.Open();
                command = new SqlCommand(sql, conn);

                dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    Output = Output + dataReader.GetValue(0) + "-" + dataReader.GetValue(1) + "</br>";

                    //Value of Textbox1 and TectBox2 is assigin on the ViewState  
                    Session["name"] = dataReader.GetValue(0).ToString();
                    Session["email"] = dataReader.GetValue(1);                   
                   
                }

                Response.Write(Output);
                dataReader.Close();
                command.Dispose();
                // save in session varibale
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
                string msg = "Insert Error:";
                msg += ex.Message;
            }
            finally
            {
               
                conn.Close();
            }

            //Console.WriteLine(UserName.Text);
           Response.Redirect("~/job_seeker_home_page.aspx");
        }
    }
}