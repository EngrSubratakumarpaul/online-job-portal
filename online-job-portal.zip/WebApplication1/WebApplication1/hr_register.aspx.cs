﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication1
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            // Save Data
            string connetionString;
            SqlConnection conn;
            SqlCommand command;
            SqlDataReader dataReader;
            String sql, Output = " ";
            string check = "1";

            //Connection String
            connetionString = @"Data Source=SHUVO;Initial Catalog=demo; Integrated Security = true";
            conn = new SqlConnection(connetionString);

            // assign filed value to variable
            String UName = UserName.Text;

            //checking user id

             // Insert code
           string sql_check = "select name from hr_data where user_id = '" + User_ID.Text + "'";
           try
           {
               conn.Open();
               command = new SqlCommand(sql_check, conn);

               dataReader = command.ExecuteReader();
               while (dataReader.Read())
               {
                   check = "2";

               }

           }
           catch (System.Data.SqlClient.SqlException ex)
           {
               string msg = "Insert Error:";
               msg += ex.Message;
           }
             finally
            {
                conn.Close();
            }


           if (check == "1")
           {

               // Insert code
               sql = "insert into hr_data(name, email, contact_no, company_name, user_id, password) values ('" + UName + "','" + Email.Text + "','" + Conatct_No.Text + "','" + Comapany_Name.Text + "','" + User_ID.Text + "','" + Password.Text + "')";
               try
               {
                   conn.Open();
                   SqlCommand cmd = new SqlCommand(sql, conn);
                   cmd.ExecuteNonQuery();
               }
               catch (System.Data.SqlClient.SqlException ex)
               {
                   string msg = "Insert Error:";
                   msg += ex.Message;
               }
               finally
               {
                   conn.Close();
               }

               message.Text = "Data saved successfully";
           }
           else
           {
               message.Text = "Data already exist. Please try again!!";

           }


            //Register
            //Response.Redirect("~/hr_home_page.aspx");
        }
    }
}