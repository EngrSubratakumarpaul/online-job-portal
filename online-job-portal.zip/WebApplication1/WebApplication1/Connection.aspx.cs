﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {
            string connetionString;
            SqlConnection cnn;
            


            connetionString = @"Data Source=SHUVO;Initial Catalog=demo; Integrated Security = true";
            cnn = new SqlConnection(connetionString);
            cnn.Open();
            Response.Write("Connection MAde");
            cnn.Close();

            if (!IsPostBack)
            {

                f1();
            }
           
	


        }

        public DataTable f1()
        {
            string connetionString;
            SqlConnection cnn;
            SqlCommand sqlquery;
            

            String sql = "select name, email, password, contact_no from job_seeker_information";
            connetionString = @"Data Source=SHUVO;Initial Catalog=demo; Integrated Security = true";
            cnn = new SqlConnection(connetionString);
            cnn.Open();
            /*sqlquery = new SqlCommand(sql, cnn);
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = sqlquery;
            DataSet ds = new DataSet();
            da.Fill(ds, "job_seeker_information");

            */

            SqlDataAdapter Adp = new SqlDataAdapter("select name, email from job_seeker_information", cnn);
            DataTable Dt = new DataTable();
            Adp.Fill(Dt);
            grid1.DataSource = Dt;
            grid1.DataBind();

            return Dt; 


               // gridview1.DataSource = ds.Tables["demo.job_seeker_information"];
              //  gridview1.DataBind();
              //  cnn.Close();


           
        }
    }
}