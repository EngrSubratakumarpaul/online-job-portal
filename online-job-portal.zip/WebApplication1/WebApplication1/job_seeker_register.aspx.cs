﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication1
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // Save Data
            string connetionString;
            SqlConnection conn;    

            //Connection String
            connetionString = @"Data Source=SHUVO;Initial Catalog=demo; Integrated Security = true";
            conn = new SqlConnection(connetionString);            

            // assign filed value to variable
            String UName = UserName.Text;


            // Insert code
            string sql = "insert into job_seeker_information(name, email, contact_no, gender, qualification, password) values ('" + UName + "','" + Email.Text + "','" + Conatct_No.Text + "','" + gender.Text + "','" + qualification.Text + "','" + Password.Text + "')";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
                string msg = "Insert Error:";
                msg += ex.Message;
            }
            finally
            {
                conn.Close();
            }

            message.Text = "Data saved successfully";
            // Redirect
            //Response.Redirect("~/job_seeker_home_page.aspx");
        }
    }
}