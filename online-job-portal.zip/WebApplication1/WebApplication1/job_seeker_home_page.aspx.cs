﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication1
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["name"] != null)
            {
                loggedin.Text = Session["name"].ToString();
            }

            if (!IsPostBack)
            {

                f1();
            }
        }
       

        protected void Button1_Click1(object sender, EventArgs e)
        {
            Session["name"] = "";
            login.Visible = false;

            Response.Redirect("~/jobSeeker.aspx");
            
        }


        public DataTable f1()
        {
            string connetionString;
            SqlConnection cnn;
            SqlCommand sqlquery;


            String sql = "select name, email, password, contact_no from job_seeker_information";
            connetionString = @"Data Source=SHUVO;Initial Catalog=demo; Integrated Security = true";
            cnn = new SqlConnection(connetionString);
            cnn.Open();

            SqlDataAdapter Adp = new SqlDataAdapter("select name, email,contact_no,company_name from hr_data", cnn);
            DataTable Dt = new DataTable();
            Adp.Fill(Dt);
            GridView1.DataSource = Dt;
            GridView1.DataBind();

            return Dt;


            // gridview1.DataSource = ds.Tables["demo.job_seeker_information"];
            //  gridview1.DataBind();
            //  cnn.Close();


        }
    }
}