﻿  using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication1
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["hr_name"] != null)
            {
                loggedin1.Text = Session["hr_name"].ToString();
            }

            if (!IsPostBack)
            {

                f1();
            }
        }


        protected void Button1_Click1(object sender, EventArgs e)
        {
            Session["hr_name"] = "";
            login.Visible = false;

            Response.Redirect("~/hr.aspx");

        }

        public DataTable f1()
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=SHUVO;Initial Catalog=demo; Integrated Security = true";
            cnn = new SqlConnection(connetionString);
            cnn.Open();           

            SqlDataAdapter Adp = new SqlDataAdapter("select name, email from job_seeker_information", cnn);
            DataTable Dt = new DataTable();
            Adp.Fill(Dt);
            grid1.DataSource = Dt;
            grid1.DataBind();

            return Dt;


            // gridview1.DataSource = ds.Tables["demo.job_seeker_information"];
            //  gridview1.DataBind();
            //  cnn.Close();



        }
    }
}